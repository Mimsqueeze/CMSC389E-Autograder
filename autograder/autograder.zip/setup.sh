#!/bin/bash
# No dependencies for this example
echo "Setup complete!"
