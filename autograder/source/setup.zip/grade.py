import amulet
import os

# Load the submitted world
def grade_world(world_path):
    world = amulet.load_level(world_path)
    score = 0

    # Example: Check if specific block is in the correct location
    block = world.get_block(1, 56, 1, "minecraft:overworld")
    if block.base_name == "redstone_wire":
        score += 10
        print("TEST PASSED")
    else:
        print("TEST FAILED")

    world.close()
    return score

# Main grading script
if __name__ == "__main__":
    score = grade_world("/autograder/source/world/")
    
    # Path to the file
    file_path = "/autograder/results/results.json"

    # Ensure the directory exists
    os.makedirs(os.path.dirname(file_path), exist_ok=True)

    # Output results
    with open(file_path, "w") as results_file:
        results_file.write(f'{{"score": {score}}}')
